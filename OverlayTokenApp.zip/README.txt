Overlay Token App!!!

Istruzioni:

- Premi ALT + T per aggiungere nuovi Token
- Fai Click con il tasto destro del mouse su un Token per modificarlo
- Se vuoi salvare i tuoi Token tra una sessione e l'altra selezione nel menù dei Token la voce "Salva tutti i Token"
- Se premendo ALT + T non appare nessun Token, non temere! Clicca sull'icona di Overlay Token App nella barra delle applicazioni e Riprova!!
- Se L'applicazione non dovesse aprirsi cliccando direttamente sull'eseguibile "OverlayTokenApp.exe" prova a fare doppio Click sul File RUN.bat

Ed ora Buon Divertimento!!!!!!
